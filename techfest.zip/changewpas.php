<?php
if(isset($_COOKIE['loginw']));
else
die("Unauthorised Access !!");
?>
<?php

@$id=$_COOKIE['IDw'];
include "connect.php";

?>
<!DOCTYPE HTML>
<html>
	<head>
		<style type="text/css">


.btn {
  -webkit-border-radius: 33;
  -moz-border-radius: 33;
  border-radius: 33px;
  text-shadow: 1px 1px 3px #666666;
  font-family: Georgia;
  color: #ffffff;
  font-size: 14px;
  background: #3498db;
  padding: 8px 20px 10px 20px;
  text-decoration: none;
}

.btn:hover {
  background: #3cb0fd;
  background-image: -webkit-linear-gradient(top, #3cb0fd, #3498db);
  background-image: -moz-linear-gradient(top, #3cb0fd, #3498db);
  background-image: -ms-linear-gradient(top, #3cb0fd, #3498db);
  background-image: -o-linear-gradient(top, #3cb0fd, #3498db);
  background-image: linear-gradient(to bottom, #3cb0fd, #3498db);
  text-decoration: none;
}
</style>

		<title>change password</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,700,500,900' rel='stylesheet' type='text/css'>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-panels.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel-noscript.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-desktop.css" />
		</noscript>
	</head>
	<body>

	<!-- Header -->
		<div id="header">
			<div id="nav-wrapper">
				<!-- Nav -->
				<nav id="nav">
					<ul>
						<li class="active"><a href="index.php">Home</a></li>
                                                <li><a href="right-sidebar.html">Mess Menu</a></li>
						<li><a href="http://www.kiet.edu/Virtualtour/web/frontview.html">Gallery</a></li>
						<li><a href="left-sidebar.html">About Us</a></li>
						<li><a href="logout.php">Logout</a></li>
					</ul>
				</nav>
			</div>
			<div class="container">

				<!-- Logo -->
				<div id="logo">
				<h1><a href="http://www.kiet.edu">KIET</a></h1>
					<span class="tag">Hostel Management System</span>
				</div>
			</div>
		</div>
	<!-- Header -->

	<!-- Main -->
		<div id="main">
			<div id="content" class="container">
				<section>
					<header>
						<h2>Change Password</h2>
						<span class="byline"></span>
					</header>

<form action="" method="POST">
<INPUT TYPE="text" name="oldpass" placeholder="Old password">
<INPUT TYPE="password" name="repass" placeholder="New password">
<INPUT TYPE="password" name="cnfrm" placeholder="Retype password">
<INPUT TYPE="submit" name="submit" class="btn" value="Change Password">
</form>
<?php

@$id=$_COOKIE['IDw'];
include "connect.php";
if(isset($_POST['submit']))
{
$row=mysql_query("SELECT * FROM `admin` WHERE hostel_id='$id'") OR die("error");
$row1=mysql_fetch_array($row);
 $old=$row1['password'];
 $r=$_POST['repass'];
 $o=$_POST['oldpass'];
 $c=$_POST['cnfrm'];
if(strcmp($old,$o)==0)
{
if(strcmp($r,$c)==0)
{

mysql_query("UPDATE `admin` SET `password`='$r'");
 echo"<script>alert('successfully changed')</script>";
   echo "<script language='javascript'>window.location.href='logout.php'</script>";
 }
else
 echo"<script>alert('confirm password is incorrect')</script>";
}
else
 echo"<script>alert('old password is incorrect')</script>";
}
?>


				</section>
			</div>
		</div>
	<!-- /Main -->

	<!-- Tweet -->
		<div id="tweet">
			<div class="container">
				<section>
					<blockquote></blockquote>
				</section>
			</div>
		</div>
	<!-- /Tweet -->

	<!-- Footer -->
		<div id="footer">
			<div class="container">
				<section>
					<header>
						<h2></h2>
						<span class="byline"></span>
					</header>
					<ul class="contact">
						<li></li>
						<li ></li>
						<li><li>
						<li></li>
					</ul>
				</section>
			</div>
		</div>
	<!-- /Footer -->


		<div id="copyright">
			<div class="container">
				Designed by:TEAM-HMS

			</div>
		</div>


	</body>
</html>